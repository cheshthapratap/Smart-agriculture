"""
Utility functions for Smart Agriculture Platform
"""
import numpy as np
from datetime import datetime, timedelta


def get_crop_calendar(crop_name, region='tropical'):
    """Returns a simplified crop growing calendar."""
    calendars = {
        'rice':      {'sow': 'Jun-Jul', 'harvest': 'Nov-Dec', 'duration': '120-150 days'},
        'wheat':     {'sow': 'Nov-Dec', 'harvest': 'Mar-Apr', 'duration': '100-130 days'},
        'maize':     {'sow': 'Jun-Jul', 'harvest': 'Oct-Nov', 'duration': '90-120 days'},
        'cotton':    {'sow': 'Apr-May', 'harvest': 'Oct-Dec', 'duration': '150-180 days'},
        'sugarcane': {'sow': 'Oct-Nov', 'harvest': 'Oct-Dec (next year)', 'duration': '12-18 months'},
    }
    return calendars.get(crop_name.lower(), {'sow': 'Varies', 'harvest': 'Varies', 'duration': 'Varies'})


def calculate_water_footprint(crop_name, yield_kg):
    """Estimates water footprint in liters per kg of crop."""
    water_footprints = {
        'rice': 1670, 'wheat': 1830, 'maize': 1220, 'cotton': 10000,
        'sugarcane': 210, 'soybean': 2145, 'groundnut': 2782,
    }
    liters_per_kg = water_footprints.get(crop_name.lower(), 1000)
    return {
        'liters_per_kg': liters_per_kg,
        'total_liters': round(liters_per_kg * yield_kg, 0),
        'cubic_meters': round(liters_per_kg * yield_kg / 1000, 2)
    }


def get_fertilizer_recommendation(N_deficiency, P_deficiency, K_deficiency):
    """Recommends fertilizer types and quantities."""
    recommendations = []
    if N_deficiency > 0:
        urea_kg = round(N_deficiency / 0.46, 2)
        recommendations.append({'fertilizer': 'Urea (46% N)', 'quantity_kg_per_ha': urea_kg})
    if P_deficiency > 0:
        ssp_kg = round(P_deficiency / 0.16, 2)
        recommendations.append({'fertilizer': 'SSP (16% P₂O₅)', 'quantity_kg_per_ha': ssp_kg})
    if K_deficiency > 0:
        mop_kg = round(K_deficiency / 0.60, 2)
        recommendations.append({'fertilizer': 'MOP (60% K₂O)', 'quantity_kg_per_ha': mop_kg})
    return recommendations


def generate_sensor_data_demo(n_points=100):
    """Generates demo IoT sensor time series data."""
    np.random.seed(42)
    timestamps = [datetime.now() - timedelta(hours=i) for i in range(n_points, 0, -1)]
    data = {
        'timestamp': [t.isoformat() for t in timestamps],
        'soil_moisture': np.clip(np.random.normal(40, 8, n_points) + np.sin(np.linspace(0, 4*np.pi, n_points)) * 5, 10, 80).tolist(),
        'temperature': np.clip(np.random.normal(25, 3, n_points) + np.sin(np.linspace(0, 2*np.pi, n_points)) * 8, 5, 45).tolist(),
        'humidity': np.clip(np.random.normal(65, 10, n_points), 20, 100).tolist(),
        'ph': np.clip(np.random.normal(6.5, 0.5, n_points), 4.0, 9.0).tolist(),
    }
    # Inject anomalies
    for col in ['soil_moisture', 'temperature']:
        anomaly_indices = np.random.choice(n_points, 5, replace=False)
        for idx in anomaly_indices:
            data[col][idx] *= np.random.uniform(1.8, 2.5)
    return data
