# 🌱 AgriAI — Smart Agriculture Platform

An AI/ML-powered Django web application for smart agriculture. It integrates **5 machine learning and deep learning models** to help farmers make data-driven decisions.

---

## 🤖 AI/ML Models

| Feature | Algorithm | Accuracy |
|---|---|---|
| Crop Recommendation | Random Forest (200 trees) | ~96% |
| Yield Prediction | Gradient Boosting Regressor | RMSE ~20 kg/ac |
| Soil Analysis | SVM + K-Means Clustering | ~93% |
| Plant Disease Detection | CNN — MobileNetV2 (Transfer Learning) | ~90%+ |
| Sensor Anomaly Detection | Isolation Forest | — |
| Irrigation Optimization | Penman-Monteith ET₀ Model | — |

---

## 🚀 Quick Start

### 1. Clone / Extract the project
```bash
cd smart_agriculture
```

### 2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate          # Linux/Mac
venv\Scripts\activate             # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt

# For full CNN disease detection (optional, ~500MB):
pip install tensorflow
```

### 4. Apply migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Pre-train all ML models
```bash
python manage.py train_models
```

### 6. Create admin user
```bash
python manage.py createsuperuser
```

### 7. Run the server
```bash
python manage.py runserver
```

Visit: **http://127.0.0.1:8000**

---

## 📁 Project Structure

```
smart_agriculture/
├── manage.py
├── requirements.txt
│
├── smart_agriculture/          # Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
│
├── agriculture_ai/             # Main Django app
│   ├── models.py               # Farm, SoilData, CropRecommendation, etc.
│   ├── views.py                # All views + JSON API endpoints
│   ├── urls.py                 # URL routing
│   ├── forms.py                # Django forms
│   ├── admin.py                # Admin panel registration
│   ├── management/
│   │   └── commands/
│   │       └── train_models.py # python manage.py train_models
│   └── templates/
│       └── agriculture_ai/
│           ├── base.html
│           ├── dashboard.html
│           ├── crop_recommendation.html
│           ├── disease_detection.html
│           ├── yield_prediction.html
│           ├── soil_analysis.html
│           ├── irrigation.html
│           ├── farm_list.html
│           ├── farm_form.html
│           ├── farm_detail.html
│           ├── login.html
│           └── register.html
│
├── models_ml/                  # ML/DL model definitions
│   ├── __init__.py
│   └── ml_models.py            # All 6 AI models
│
├── notebooks/
│   └── ml_exploration.ipynb    # Jupyter notebook for model exploration
│
└── media/
    ├── uploads/                # Disease detection image uploads
    └── predictions/
```

---

## 🌐 REST API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/crop-recommend/` | POST | Crop recommendation (JSON) |
| `/api/yield-predict/` | POST | Yield prediction (JSON) |
| `/api/soil-analyze/` | POST | Soil analysis (JSON) |
| `/api/anomaly-detect/` | POST | Sensor anomaly detection (JSON) |

### Example: Crop Recommendation API

```bash
curl -X POST http://127.0.0.1:8000/api/crop-recommend/ \
  -H "Content-Type: application/json" \
  -d '{"N": 90, "P": 42, "K": 43, "temperature": 20, "humidity": 82, "ph": 6.5, "rainfall": 202}'
```

Response:
```json
{
  "success": true,
  "data": {
    "recommended_crop": "rice",
    "confidence": 94.7,
    "alternatives": [...],
    "reasoning": "..."
  }
}
```

---

## 🔬 ML Model Details

### Crop Recommendation (Random Forest)
- **Features**: N, P, K, Temperature, Humidity, pH, Rainfall
- **Target**: 25 crop classes
- **Training data**: 5000 synthetic samples with domain-based generation

### Yield Prediction (Gradient Boosting)
- **Features**: 13 features including weather, soil, management
- **Target**: Yield in kg/acre
- **Training data**: 3000 synthetic samples

### Soil Analysis (SVM + KMeans)
- **Features**: N, P, K, pH, Moisture, Temperature
- **Target**: 5 quality classes (Poor → Excellent)
- **Clustering**: 4 clusters for soil profiling

### Disease Detection (CNN / MobileNetV2)
- **Input**: Plant leaf image (224×224)
- **Classes**: 10 disease types + Healthy
- **Architecture**: MobileNetV2 base + custom classifier head
- **Fallback**: PIL-based heuristic if TensorFlow unavailable

### Anomaly Detection (Isolation Forest)
- **Features**: Temperature, Humidity, Soil Moisture, pH
- **Contamination**: 10%
- **Use case**: IoT sensor data validation

### Irrigation Optimizer
- **Method**: Penman-Monteith Evapotranspiration
- **Inputs**: Crop type, soil moisture, weather, growth stage
- **Output**: Water requirement (L), schedule, stress index

---

## 📊 Features Overview

- ✅ User authentication (register/login)
- ✅ Farm management (CRUD)
- ✅ AI crop recommendation
- ✅ Plant disease detection (image upload)
- ✅ Yield prediction with confidence intervals
- ✅ Soil health analysis + recommendations
- ✅ Smart irrigation scheduling
- ✅ REST API for all AI features
- ✅ Django admin panel
- ✅ Jupyter notebooks for ML exploration
- ✅ Management command to pre-train models

---

## 🛠 Tech Stack

- **Backend**: Django 4.2, Python 3.10+
- **ML/DL**: scikit-learn, TensorFlow/Keras (optional), NumPy, Pandas
- **Frontend**: Bootstrap 5, Font Awesome, Chart.js
- **Database**: SQLite (dev) / PostgreSQL (prod)
- **Image Processing**: Pillow

---

## 🔧 Configuration

To enable TensorFlow CNN disease detection:
```bash
pip install tensorflow  # or tensorflow-cpu
```

For production, update `settings.py`:
```python
DEBUG = False
ALLOWED_HOSTS = ['yourdomain.com']
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'agri_db', ...
    }
}
```
