"""
ML Models for Smart Agriculture
================================
- Crop Recommendation (Random Forest)
- Disease Detection (CNN with TensorFlow/Keras)
- Yield Prediction (Gradient Boosting)
- Soil Analysis (SVM + Clustering)
- Irrigation Optimizer (Rule-based + ML)
- Anomaly Detection (Isolation Forest)
"""

import numpy as np
import pandas as pd
import pickle
import os
import logging
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor, IsolationForest
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────
# 1. CROP RECOMMENDATION MODEL (Random Forest)
# ─────────────────────────────────────────────────

class CropRecommendationModel:
    """
    Recommends the best crop based on soil and climate parameters.
    Features: N, P, K, temperature, humidity, pH, rainfall
    """

    CROPS = [
        'rice', 'maize', 'chickpea', 'kidneybeans', 'pigeonpeas',
        'mothbeans', 'mungbean', 'blackgram', 'lentil', 'pomegranate',
        'banana', 'mango', 'grapes', 'watermelon', 'muskmelon',
        'apple', 'orange', 'papaya', 'coconut', 'cotton',
        'jute', 'coffee', 'wheat', 'sugarcane', 'sunflower'
    ]

    CROP_IDEAL_CONDITIONS = {
        'rice':        {'N': (80,100), 'P': (40,60), 'K': (40,50), 'temp': (20,35), 'humidity': (80,90), 'ph': (5.5,7.0), 'rainfall': (200,300)},
        'wheat':       {'N': (60,80),  'P': (40,60), 'K': (40,60), 'temp': (12,25), 'humidity': (50,70), 'ph': (6.0,7.5), 'rainfall': (50,100)},
        'maize':       {'N': (70,90),  'P': (45,65), 'K': (40,60), 'temp': (18,30), 'humidity': (55,75), 'ph': (5.8,7.0), 'rainfall': (50,100)},
        'cotton':      {'N': (115,135),'P': (40,60), 'K': (18,25), 'temp': (21,35), 'humidity': (65,75), 'ph': (6.0,7.5), 'rainfall': (50,100)},
        'sugarcane':   {'N': (60,80),  'P': (30,50), 'K': (18,25), 'temp': (22,35), 'humidity': (65,80), 'ph': (6.0,7.5), 'rainfall': (100,200)},
    }

    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=200,
            max_depth=15,
            min_samples_split=5,
            random_state=42,
            n_jobs=-1
        )
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.is_trained = False

    def generate_synthetic_data(self, n_samples=5000):
        """Generate synthetic training data for demo purposes."""
        np.random.seed(42)
        data = []
        crops_subset = self.CROPS[:15]

        for crop in crops_subset:
            n = n_samples // len(crops_subset)
            conditions = self.CROP_IDEAL_CONDITIONS.get(crop, {
                'N': (50,100), 'P': (30,60), 'K': (20,50),
                'temp': (15,35), 'humidity': (40,90),
                'ph': (5.5,7.5), 'rainfall': (50,200)
            })
            samples = {
                'N': np.random.uniform(*conditions['N'], n),
                'P': np.random.uniform(*conditions['P'], n),
                'K': np.random.uniform(*conditions['K'], n),
                'temperature': np.random.uniform(*conditions['temp'], n),
                'humidity': np.random.uniform(*conditions['humidity'], n),
                'ph': np.random.uniform(*conditions['ph'], n),
                'rainfall': np.random.uniform(*conditions['rainfall'], n),
                'label': [crop] * n
            }
            data.append(pd.DataFrame(samples))

        return pd.concat(data, ignore_index=True)

    def train(self, X=None, y=None):
        """Train the crop recommendation model."""
        if X is None:
            df = self.generate_synthetic_data()
            X = df[['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
            y = df['label']

        y_encoded = self.label_encoder.fit_transform(y)
        X_scaled = self.scaler.fit_transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_encoded, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)
        acc = accuracy_score(y_test, self.model.predict(X_test))
        self.is_trained = True
        logger.info(f"Crop model trained. Accuracy: {acc:.4f}")
        return acc

    def predict(self, N, P, K, temperature, humidity, ph, rainfall):
        """Predict best crop and top alternatives."""
        if not self.is_trained:
            self.train()

        features = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
        features_scaled = self.scaler.transform(features)
        probabilities = self.model.predict_proba(features_scaled)[0]
        top_indices = np.argsort(probabilities)[::-1][:5]

        recommended = self.label_encoder.inverse_transform([top_indices[0]])[0]
        confidence = float(probabilities[top_indices[0]])
        alternatives = [
            {
                'crop': self.label_encoder.inverse_transform([i])[0],
                'confidence': float(probabilities[i])
            }
            for i in top_indices[1:]
        ]
        return {
            'recommended_crop': recommended,
            'confidence': round(confidence * 100, 2),
            'alternatives': alternatives,
            'reasoning': self._generate_reasoning(N, P, K, temperature, humidity, ph, rainfall, recommended)
        }

    def _generate_reasoning(self, N, P, K, temp, humidity, ph, rainfall, crop):
        reasons = []
        if N > 80: reasons.append("High nitrogen content supports leafy crops")
        elif N < 40: reasons.append("Low nitrogen suits nitrogen-fixing legumes")
        if ph < 6.0: reasons.append("Acidic soil favors acid-tolerant crops")
        elif ph > 7.5: reasons.append("Alkaline soil suits drought-resistant crops")
        if rainfall > 150: reasons.append("High rainfall supports water-intensive crops")
        if temp > 30: reasons.append("High temperature favors tropical crops")
        reasons.append(f"{crop.capitalize()} is optimal for these combined conditions")
        return ". ".join(reasons) + "."

    def save(self, path):
        with open(path, 'wb') as f:
            pickle.dump({'model': self.model, 'scaler': self.scaler,
                         'label_encoder': self.label_encoder, 'is_trained': self.is_trained}, f)

    def load(self, path):
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self.model = data['model']
            self.scaler = data['scaler']
            self.label_encoder = data['label_encoder']
            self.is_trained = data['is_trained']
            return True
        return False


# ─────────────────────────────────────────────────
# 2. YIELD PREDICTION MODEL (Gradient Boosting)
# ─────────────────────────────────────────────────

class YieldPredictionModel:
    """
    Predicts crop yield based on soil, weather, and crop management features.
    """

    def __init__(self):
        self.model = GradientBoostingRegressor(
            n_estimators=300,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.8,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.feature_names = [
            'temperature', 'rainfall', 'humidity', 'soil_ph',
            'nitrogen', 'phosphorus', 'potassium', 'area_acres',
            'irrigation_count', 'fertilizer_usage', 'pesticide_usage',
            'soil_moisture', 'solar_radiation'
        ]

    def generate_synthetic_data(self, n_samples=3000):
        np.random.seed(42)
        df = pd.DataFrame({
            'temperature': np.random.uniform(15, 40, n_samples),
            'rainfall': np.random.uniform(50, 300, n_samples),
            'humidity': np.random.uniform(40, 95, n_samples),
            'soil_ph': np.random.uniform(4.5, 8.5, n_samples),
            'nitrogen': np.random.uniform(20, 140, n_samples),
            'phosphorus': np.random.uniform(5, 145, n_samples),
            'potassium': np.random.uniform(5, 205, n_samples),
            'area_acres': np.random.uniform(0.5, 50, n_samples),
            'irrigation_count': np.random.randint(0, 20, n_samples),
            'fertilizer_usage': np.random.uniform(0, 300, n_samples),
            'pesticide_usage': np.random.uniform(0, 10, n_samples),
            'soil_moisture': np.random.uniform(10, 60, n_samples),
            'solar_radiation': np.random.uniform(100, 400, n_samples),
        })
        # Synthetic yield formula
        df['yield_kg_per_acre'] = (
            50 + 0.5 * df['nitrogen'] + 0.3 * df['phosphorus'] + 0.2 * df['potassium']
            - 2 * abs(df['soil_ph'] - 6.5) + 0.1 * df['rainfall']
            + 0.5 * df['irrigation_count'] + 0.1 * df['solar_radiation']
            + np.random.normal(0, 20, n_samples)
        ).clip(100, 2000)
        return df

    def train(self, X=None, y=None):
        if X is None:
            df = self.generate_synthetic_data()
            X = df[self.feature_names]
            y = df['yield_kg_per_acre']

        X_scaled = self.scaler.fit_transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        self.is_trained = True
        logger.info(f"Yield model trained. RMSE: {rmse:.2f}")
        return rmse

    def predict(self, features_dict):
        if not self.is_trained:
            self.train()
        features = np.array([[features_dict.get(f, 0) for f in self.feature_names]])
        features_scaled = self.scaler.transform(features)
        predicted_yield = float(self.model.predict(features_scaled)[0])
        return {
            'predicted_yield_kg_per_acre': round(predicted_yield, 2),
            'predicted_yield_tons_per_acre': round(predicted_yield / 1000, 3),
            'confidence_interval': {
                'lower': round(predicted_yield * 0.85, 2),
                'upper': round(predicted_yield * 1.15, 2)
            },
            'feature_importance': self._get_feature_importance()
        }

    def _get_feature_importance(self):
        importances = self.model.feature_importances_
        return dict(sorted(zip(self.feature_names, importances.tolist()),
                           key=lambda x: x[1], reverse=True)[:5])

    def save(self, path):
        with open(path, 'wb') as f:
            pickle.dump({'model': self.model, 'scaler': self.scaler, 'is_trained': self.is_trained}, f)

    def load(self, path):
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self.model = data['model']
            self.scaler = data['scaler']
            self.is_trained = data['is_trained']
            return True
        return False


# ─────────────────────────────────────────────────
# 3. SOIL ANALYSIS MODEL (SVM + KMeans Clustering)
# ─────────────────────────────────────────────────

class SoilAnalysisModel:
    """
    Analyzes soil health and classifies soil quality using SVM and clustering.
    """

    SOIL_QUALITY_LABELS = {0: 'Poor', 1: 'Below Average', 2: 'Average', 3: 'Good', 4: 'Excellent'}

    def __init__(self):
        self.classifier = SVC(kernel='rbf', probability=True, C=10, gamma='scale')
        self.scaler = StandardScaler()
        self.kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
        self.is_trained = False

    def analyze(self, N, P, K, ph, moisture, temperature, organic_matter=None):
        """Analyze soil and return health score + recommendations."""
        if not self.is_trained:
            self.train()

        features = np.array([[N, P, K, ph, moisture, temperature]])
        features_scaled = self.scaler.transform(features)
        quality_pred = self.classifier.predict(features_scaled)[0]
        quality_proba = self.classifier.predict_proba(features_scaled)[0]
        cluster = self.kmeans.predict(features_scaled)[0]

        health_score = self._compute_health_score(N, P, K, ph, moisture)
        recommendations = self._generate_recommendations(N, P, K, ph, moisture)

        return {
            'soil_quality': self.SOIL_QUALITY_LABELS.get(quality_pred, 'Unknown'),
            'health_score': health_score,
            'cluster': int(cluster),
            'nutrient_status': {
                'nitrogen': self._status(N, 40, 80),
                'phosphorus': self._status(P, 20, 60),
                'potassium': self._status(K, 20, 60),
            },
            'ph_status': 'Acidic' if ph < 6 else ('Alkaline' if ph > 7.5 else 'Neutral'),
            'moisture_status': 'Dry' if moisture < 20 else ('Waterlogged' if moisture > 70 else 'Optimal'),
            'recommendations': recommendations,
            'confidence': round(float(max(quality_proba)) * 100, 2)
        }

    def _status(self, value, low, high):
        if value < low: return 'Low'
        elif value > high: return 'High'
        return 'Optimal'

    def _compute_health_score(self, N, P, K, ph, moisture):
        score = 0
        score += min(N / 100 * 20, 20)
        score += min(P / 60 * 20, 20)
        score += min(K / 60 * 20, 20)
        score += max(0, 20 - abs(ph - 6.5) * 10)
        score += max(0, 20 - abs(moisture - 40) * 0.5)
        return round(score, 1)

    def _generate_recommendations(self, N, P, K, ph, moisture):
        recs = []
        if N < 40: recs.append("Apply nitrogen-rich fertilizer (urea or ammonium nitrate)")
        elif N > 100: recs.append("Reduce nitrogen application to prevent toxicity")
        if P < 20: recs.append("Add phosphate fertilizer to improve root development")
        if K < 20: recs.append("Apply potash fertilizer for better fruit and grain quality")
        if ph < 6.0: recs.append("Apply agricultural lime to raise pH")
        elif ph > 7.5: recs.append("Add sulfur or acidic organic matter to lower pH")
        if moisture < 20: recs.append("Increase irrigation frequency")
        elif moisture > 70: recs.append("Improve drainage to reduce waterlogging")
        if not recs:
            recs.append("Soil conditions are optimal. Maintain current practices.")
        return recs

    def train(self):
        np.random.seed(42)
        n = 2000
        X = np.column_stack([
            np.random.uniform(10, 140, n),
            np.random.uniform(5, 145, n),
            np.random.uniform(5, 205, n),
            np.random.uniform(4.5, 8.5, n),
            np.random.uniform(10, 80, n),
            np.random.uniform(10, 40, n),
        ])
        # Quality based on balanced nutrients
        y = np.zeros(n, dtype=int)
        for i, row in enumerate(X):
            s = (min(row[0]/80, 1) + min(row[1]/50, 1) + min(row[2]/50, 1) +
                 max(0, 1 - abs(row[3]-6.5)/3) + max(0, 1 - abs(row[4]-40)/40)) / 5
            y[i] = min(int(s * 5), 4)

        X_scaled = self.scaler.fit_transform(X)
        self.classifier.fit(X_scaled, y)
        self.kmeans.fit(X_scaled)
        self.is_trained = True

    def save(self, path):
        with open(path, 'wb') as f:
            pickle.dump({'classifier': self.classifier, 'scaler': self.scaler,
                         'kmeans': self.kmeans, 'is_trained': self.is_trained}, f)

    def load(self, path):
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self.classifier = data['classifier']
            self.scaler = data['scaler']
            self.kmeans = data['kmeans']
            self.is_trained = data['is_trained']
            return True
        return False


# ─────────────────────────────────────────────────
# 4. ANOMALY DETECTION (Isolation Forest)
# ─────────────────────────────────────────────────

class AnomalyDetectionModel:
    """
    Detects anomalies in sensor data using Isolation Forest.
    """

    def __init__(self):
        self.model = IsolationForest(contamination=0.1, random_state=42, n_estimators=100)
        self.scaler = StandardScaler()
        self.is_trained = False

    def train(self, data=None):
        if data is None:
            np.random.seed(42)
            n = 1000
            data = np.column_stack([
                np.random.normal(25, 5, n),   # temperature
                np.random.normal(60, 10, n),   # humidity
                np.random.normal(40, 8, n),    # soil moisture
                np.random.normal(6.5, 0.5, n), # pH
            ])
        data_scaled = self.scaler.fit_transform(data)
        self.model.fit(data_scaled)
        self.is_trained = True

    def detect(self, sensor_readings):
        if not self.is_trained:
            self.train()
        features = np.array([sensor_readings])
        features_scaled = self.scaler.transform(features)
        prediction = self.model.predict(features_scaled)[0]
        score = self.model.score_samples(features_scaled)[0]
        return {
            'is_anomaly': prediction == -1,
            'anomaly_score': round(float(score), 4),
            'severity': 'High' if score < -0.5 else ('Medium' if score < -0.3 else 'Low')
        }

    def save(self, path):
        with open(path, 'wb') as f:
            pickle.dump({'model': self.model, 'scaler': self.scaler, 'is_trained': self.is_trained}, f)

    def load(self, path):
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self.model = data['model']
            self.scaler = data['scaler']
            self.is_trained = data['is_trained']
            return True
        return False


# ─────────────────────────────────────────────────
# 5. DISEASE DETECTION (Deep Learning CNN - Keras)
# ─────────────────────────────────────────────────

class DiseaseDetectionModel:
    """
    Plant disease detection using a CNN (MobileNetV2 transfer learning).
    Falls back to a simpler heuristic if TensorFlow is unavailable.
    """

    DISEASES = [
        'Healthy', 'Bacterial Blight', 'Brown Spot', 'Leaf Rust',
        'Powdery Mildew', 'Downy Mildew', 'Mosaic Virus', 'Root Rot',
        'Anthracnose', 'Cercospora Leaf Spot'
    ]

    TREATMENTS = {
        'Healthy': 'No treatment needed. Continue regular monitoring.',
        'Bacterial Blight': 'Apply copper-based bactericide. Remove infected leaves. Ensure proper drainage.',
        'Brown Spot': 'Apply fungicide (Mancozeb/Carbendazim). Avoid overhead irrigation.',
        'Leaf Rust': 'Apply triazole fungicide. Remove infected plant parts. Ensure air circulation.',
        'Powdery Mildew': 'Apply sulfur-based fungicide. Reduce humidity. Avoid wetting leaves.',
        'Downy Mildew': 'Apply metalaxyl fungicide. Improve air circulation. Rotate crops.',
        'Mosaic Virus': 'Remove infected plants. Control aphid vectors. Use virus-free seeds.',
        'Root Rot': 'Improve drainage. Apply fungicide drench. Reduce irrigation.',
        'Anthracnose': 'Apply copper fungicide. Prune infected parts. Avoid overhead watering.',
        'Cercospora Leaf Spot': 'Apply fungicide. Remove infected leaves. Practice crop rotation.',
    }

    def __init__(self):
        self.model = None
        self.tf_available = False
        self._try_load_tf()

    def _try_load_tf(self):
        try:
            import tensorflow as tf
            self.tf_available = True
        except ImportError:
            logger.warning("TensorFlow not available. Using heuristic disease detection.")

    def build_cnn_model(self, num_classes=10, input_shape=(224, 224, 3)):
        """Build CNN using MobileNetV2 transfer learning."""
        try:
            import tensorflow as tf
            from tensorflow.keras import layers, models
            from tensorflow.keras.applications import MobileNetV2

            base_model = MobileNetV2(input_shape=input_shape, include_top=False, weights='imagenet')
            base_model.trainable = False

            model = models.Sequential([
                base_model,
                layers.GlobalAveragePooling2D(),
                layers.BatchNormalization(),
                layers.Dense(256, activation='relu'),
                layers.Dropout(0.4),
                layers.Dense(128, activation='relu'),
                layers.Dropout(0.3),
                layers.Dense(num_classes, activation='softmax')
            ])

            model.compile(
                optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                loss='categorical_crossentropy',
                metrics=['accuracy']
            )
            self.model = model
            return model
        except Exception as e:
            logger.error(f"Failed to build CNN: {e}")
            return None

    def predict_from_image(self, image_path):
        """Predict disease from image path."""
        if self.tf_available and self.model is not None:
            return self._predict_with_cnn(image_path)
        return self._heuristic_predict(image_path)

    def _predict_with_cnn(self, image_path):
        try:
            import tensorflow as tf
            img = tf.keras.preprocessing.image.load_img(image_path, target_size=(224, 224))
            img_array = tf.keras.preprocessing.image.img_to_array(img) / 255.0
            img_array = np.expand_dims(img_array, 0)
            preds = self.model.predict(img_array)[0]
            top_idx = np.argmax(preds)
            disease = self.DISEASES[top_idx % len(self.DISEASES)]
            confidence = float(preds[top_idx]) * 100
            severity = 'healthy' if disease == 'Healthy' else ('severe' if confidence > 80 else 'moderate')
            return {
                'disease_name': disease,
                'confidence': round(confidence, 2),
                'severity': severity,
                'treatment': self.TREATMENTS.get(disease, 'Consult an agronomist.'),
                'method': 'CNN (MobileNetV2)'
            }
        except Exception as e:
            return self._heuristic_predict(image_path)

    def _heuristic_predict(self, image_path):
        """Heuristic predict using image stats when TF unavailable."""
        try:
            from PIL import Image
            img = Image.open(image_path).convert('RGB')
            img_array = np.array(img)
            avg_green = np.mean(img_array[:, :, 1])
            avg_red = np.mean(img_array[:, :, 0])
            avg_brown = (avg_red + np.mean(img_array[:, :, 2])) / 2

            if avg_green > 120 and avg_red < 100:
                disease, confidence = 'Healthy', 88.5
            elif avg_brown > 120 and avg_green < 90:
                disease, confidence = 'Brown Spot', 76.3
            elif avg_red > 130:
                disease, confidence = 'Leaf Rust', 72.1
            elif avg_green < 80:
                disease, confidence = 'Bacterial Blight', 68.4
            else:
                disease, confidence = 'Powdery Mildew', 65.0

            severity = 'healthy' if disease == 'Healthy' else ('severe' if confidence > 80 else 'moderate')
            return {
                'disease_name': disease,
                'confidence': confidence,
                'severity': severity,
                'treatment': self.TREATMENTS.get(disease, 'Consult an agronomist.'),
                'method': 'Heuristic (PIL)'
            }
        except Exception:
            disease = np.random.choice(self.DISEASES)
            return {
                'disease_name': disease,
                'confidence': round(np.random.uniform(60, 95), 2),
                'severity': 'moderate',
                'treatment': self.TREATMENTS.get(disease, 'Consult an agronomist.'),
                'method': 'Demo'
            }


# ─────────────────────────────────────────────────
# 6. IRRIGATION OPTIMIZER
# ─────────────────────────────────────────────────

class IrrigationOptimizer:
    """
    AI-powered irrigation scheduling based on soil, weather and crop needs.
    """

    CROP_WATER_NEEDS = {
        'rice': 8.0, 'wheat': 4.5, 'maize': 5.5, 'cotton': 6.0,
        'sugarcane': 7.5, 'vegetables': 5.0, 'fruits': 6.5, 'pulses': 3.5
    }

    def optimize(self, crop_type, soil_moisture, temperature, humidity,
                  rainfall_forecast, area_acres, growth_stage='vegetative'):
        crop_need = self.CROP_WATER_NEEDS.get(crop_type.lower(), 5.0)

        # Evapotranspiration estimate (simplified Penman-Monteith)
        et0 = (0.0023 * (temperature + 17.8) * (45 - humidity / 2) * 0.5)
        kc = {'seedling': 0.4, 'vegetative': 0.8, 'flowering': 1.15, 'maturity': 0.7}.get(growth_stage, 0.8)
        etc = et0 * kc

        # Net irrigation requirement
        effective_rain = min(rainfall_forecast, crop_need)
        soil_deficit = max(0, 60 - soil_moisture)
        water_needed = max(0, (etc + soil_deficit * 0.1 - effective_rain) * area_acres * 1000)

        if water_needed < 100:
            recommendation = "No irrigation needed today"
            should_irrigate = False
        elif water_needed < 500:
            recommendation = "Light irrigation recommended"
            should_irrigate = True
        else:
            recommendation = "Full irrigation required"
            should_irrigate = True

        duration = int(water_needed / 100) if should_irrigate else 0

        return {
            'should_irrigate': should_irrigate,
            'water_amount_liters': round(water_needed, 0),
            'duration_minutes': duration,
            'evapotranspiration': round(etc, 2),
            'recommendation': recommendation,
            'water_stress_index': round(max(0, (60 - soil_moisture) / 60), 2),
            'next_irrigation': 'Today' if should_irrigate else 'In 2-3 days'
        }
