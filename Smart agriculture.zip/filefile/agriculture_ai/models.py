from django.db import models
from django.contrib.auth.models import User


class Farm(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='farms')
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=300)
    area_acres = models.FloatField()
    soil_type = models.CharField(max_length=100, choices=[
        ('clay', 'Clay'), ('sandy', 'Sandy'), ('loamy', 'Loamy'),
        ('silty', 'Silty'), ('peaty', 'Peaty'), ('chalky', 'Chalky'),
    ])
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.user.username}"


class SoilData(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='soil_records')
    nitrogen = models.FloatField(help_text='Nitrogen content (kg/ha)')
    phosphorus = models.FloatField(help_text='Phosphorus content (kg/ha)')
    potassium = models.FloatField(help_text='Potassium content (kg/ha)')
    ph_level = models.FloatField(help_text='pH level (0-14)')
    moisture = models.FloatField(help_text='Moisture percentage')
    temperature = models.FloatField(help_text='Soil temperature (°C)')
    humidity = models.FloatField(help_text='Humidity percentage')
    rainfall = models.FloatField(help_text='Rainfall (mm)')
    recorded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Soil Data for {self.farm.name} at {self.recorded_at}"


class CropRecommendation(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='crop_recommendations')
    soil_data = models.OneToOneField(SoilData, on_delete=models.CASCADE)
    recommended_crop = models.CharField(max_length=100)
    confidence_score = models.FloatField()
    alternative_crops = models.JSONField(default=list)
    reasoning = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Crop: {self.recommended_crop} for {self.farm.name}"


class DiseaseDetection(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='disease_detections')
    image = models.ImageField(upload_to='uploads/disease_images/')
    crop_type = models.CharField(max_length=100)
    disease_name = models.CharField(max_length=200, blank=True)
    confidence_score = models.FloatField(null=True, blank=True)
    severity = models.CharField(max_length=50, choices=[
        ('healthy', 'Healthy'), ('mild', 'Mild'), ('moderate', 'Moderate'), ('severe', 'Severe')
    ], blank=True)
    treatment_recommendation = models.TextField(blank=True)
    detected_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Disease: {self.disease_name} on {self.crop_type}"


class YieldPrediction(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='yield_predictions')
    crop_type = models.CharField(max_length=100)
    season = models.CharField(max_length=50)
    year = models.IntegerField()
    predicted_yield = models.FloatField(help_text='Predicted yield in kg/acre')
    actual_yield = models.FloatField(null=True, blank=True, help_text='Actual yield in kg/acre')
    weather_data = models.JSONField(default=dict)
    soil_health_score = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Yield prediction: {self.crop_type} ({self.year}) - {self.farm.name}"


class WeatherData(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='weather_records')
    temperature_max = models.FloatField()
    temperature_min = models.FloatField()
    humidity = models.FloatField()
    rainfall = models.FloatField()
    wind_speed = models.FloatField()
    solar_radiation = models.FloatField(null=True, blank=True)
    recorded_date = models.DateField()
    forecast = models.JSONField(default=dict)

    def __str__(self):
        return f"Weather for {self.farm.name} on {self.recorded_date}"


class IrrigationSchedule(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='irrigation_schedules')
    crop_type = models.CharField(max_length=100)
    schedule_date = models.DateField()
    water_amount_liters = models.FloatField()
    duration_minutes = models.IntegerField()
    ai_recommended = models.BooleanField(default=True)
    status = models.CharField(max_length=50, choices=[
        ('scheduled', 'Scheduled'), ('completed', 'Completed'), ('skipped', 'Skipped')
    ], default='scheduled')
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"Irrigation: {self.farm.name} on {self.schedule_date}"


class SensorData(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='sensor_data')
    sensor_id = models.CharField(max_length=100)
    sensor_type = models.CharField(max_length=50, choices=[
        ('soil_moisture', 'Soil Moisture'), ('temperature', 'Temperature'),
        ('humidity', 'Humidity'), ('light', 'Light Intensity'),
        ('co2', 'CO2 Level'), ('ph', 'pH Sensor'),
    ])
    value = models.FloatField()
    unit = models.CharField(max_length=20)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_anomaly = models.BooleanField(default=False)

    def __str__(self):
        return f"Sensor {self.sensor_id}: {self.value} {self.unit}"
