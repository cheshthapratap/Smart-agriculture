import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt

from .models import Farm, SoilData, CropRecommendation, DiseaseDetection, YieldPrediction, IrrigationSchedule
from .forms import FarmForm, SoilDataForm, DiseaseDetectionForm, YieldPredictionForm, IrrigationForm

# Lazy-load ML models
_crop_model = None
_yield_model = None
_soil_model = None
_disease_model = None
_anomaly_model = None
_irrigation_optimizer = None


def get_crop_model():
    global _crop_model
    if _crop_model is None:
        from models_ml import CropRecommendationModel
        _crop_model = CropRecommendationModel()
    return _crop_model


def get_yield_model():
    global _yield_model
    if _yield_model is None:
        from models_ml import YieldPredictionModel
        _yield_model = YieldPredictionModel()
    return _yield_model


def get_soil_model():
    global _soil_model
    if _soil_model is None:
        from models_ml import SoilAnalysisModel
        _soil_model = SoilAnalysisModel()
    return _soil_model


def get_disease_model():
    global _disease_model
    if _disease_model is None:
        from models_ml import DiseaseDetectionModel
        _disease_model = DiseaseDetectionModel()
    return _disease_model


def get_anomaly_model():
    global _anomaly_model
    if _anomaly_model is None:
        from models_ml import AnomalyDetectionModel
        _anomaly_model = AnomalyDetectionModel()
    return _anomaly_model


def get_irrigation_optimizer():
    global _irrigation_optimizer
    if _irrigation_optimizer is None:
        from models_ml import IrrigationOptimizer
        _irrigation_optimizer = IrrigationOptimizer()
    return _irrigation_optimizer


# ─────────────────────────────────────────────────
# AUTH VIEWS
# ─────────────────────────────────────────────────

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'agriculture_ai/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'agriculture_ai/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


# ─────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────

@login_required
def dashboard(request):
    farms = Farm.objects.filter(user=request.user)
    total_recommendations = CropRecommendation.objects.filter(farm__user=request.user).count()
    total_disease_scans = DiseaseDetection.objects.filter(farm__user=request.user).count()
    total_yield_predictions = YieldPrediction.objects.filter(farm__user=request.user).count()
    recent_recommendations = CropRecommendation.objects.filter(
        farm__user=request.user).order_by('-created_at')[:5]
    recent_diseases = DiseaseDetection.objects.filter(
        farm__user=request.user).order_by('-detected_at')[:5]

    context = {
        'farms': farms,
        'total_farms': farms.count(),
        'total_recommendations': total_recommendations,
        'total_disease_scans': total_disease_scans,
        'total_yield_predictions': total_yield_predictions,
        'recent_recommendations': recent_recommendations,
        'recent_diseases': recent_diseases,
    }
    return render(request, 'agriculture_ai/dashboard.html', context)


# ─────────────────────────────────────────────────
# FARM VIEWS
# ─────────────────────────────────────────────────

@login_required
def farm_list(request):
    farms = Farm.objects.filter(user=request.user)
    return render(request, 'agriculture_ai/farm_list.html', {'farms': farms})


@login_required
def farm_create(request):
    if request.method == 'POST':
        form = FarmForm(request.POST)
        if form.is_valid():
            farm = form.save(commit=False)
            farm.user = request.user
            farm.save()
            messages.success(request, f'Farm "{farm.name}" created successfully!')
            return redirect('farm_list')
    else:
        form = FarmForm()
    return render(request, 'agriculture_ai/farm_form.html', {'form': form, 'title': 'Add Farm'})


@login_required
def farm_detail(request, pk):
    farm = get_object_or_404(Farm, pk=pk, user=request.user)
    soil_records = farm.soil_records.order_by('-recorded_at')[:10]
    crop_recs = farm.crop_recommendations.order_by('-created_at')[:5]
    disease_detections = farm.disease_detections.order_by('-detected_at')[:5]
    yield_predictions = farm.yield_predictions.order_by('-created_at')[:5]
    return render(request, 'agriculture_ai/farm_detail.html', {
        'farm': farm,
        'soil_records': soil_records,
        'crop_recs': crop_recs,
        'disease_detections': disease_detections,
        'yield_predictions': yield_predictions,
    })


# ─────────────────────────────────────────────────
# CROP RECOMMENDATION
# ─────────────────────────────────────────────────

@login_required
def crop_recommendation(request):
    farms = Farm.objects.filter(user=request.user)
    result = None
    if request.method == 'POST':
        form = SoilDataForm(request.POST)
        farm_id = request.POST.get('farm_id')
        farm = get_object_or_404(Farm, pk=farm_id, user=request.user) if farm_id else None

        if form.is_valid() and farm:
            soil = form.save(commit=False)
            soil.farm = farm
            soil.save()

            model = get_crop_model()
            result = model.predict(
                N=soil.nitrogen, P=soil.phosphorus, K=soil.potassium,
                temperature=soil.temperature, humidity=soil.humidity,
                ph=soil.ph_level, rainfall=soil.rainfall
            )

            CropRecommendation.objects.create(
                farm=farm,
                soil_data=soil,
                recommended_crop=result['recommended_crop'],
                confidence_score=result['confidence'],
                alternative_crops=result['alternatives'],
                reasoning=result['reasoning']
            )
            messages.success(request, f"Recommended crop: {result['recommended_crop']}")
    else:
        form = SoilDataForm()

    return render(request, 'agriculture_ai/crop_recommendation.html', {
        'form': form, 'farms': farms, 'result': result
    })


# ─────────────────────────────────────────────────
# DISEASE DETECTION
# ─────────────────────────────────────────────────

@login_required
def disease_detection(request):
    farms = Farm.objects.filter(user=request.user)
    result = None
    detection = None

    if request.method == 'POST':
        form = DiseaseDetectionForm(request.POST, request.FILES)
        farm_id = request.POST.get('farm_id')
        farm = get_object_or_404(Farm, pk=farm_id, user=request.user) if farm_id else None

        if form.is_valid() and farm:
            detection = form.save(commit=False)
            detection.farm = farm
            detection.save()

            model = get_disease_model()
            result = model.predict_from_image(detection.image.path)

            detection.disease_name = result['disease_name']
            detection.confidence_score = result['confidence']
            detection.severity = result['severity']
            detection.treatment_recommendation = result['treatment']
            detection.save()

            messages.success(request, f"Disease detected: {result['disease_name']}")
    else:
        form = DiseaseDetectionForm()

    return render(request, 'agriculture_ai/disease_detection.html', {
        'form': form, 'farms': farms, 'result': result, 'detection': detection
    })


# ─────────────────────────────────────────────────
# YIELD PREDICTION
# ─────────────────────────────────────────────────

@login_required
def yield_prediction(request):
    farms = Farm.objects.filter(user=request.user)
    result = None

    if request.method == 'POST':
        form = YieldPredictionForm(request.POST)
        farm_id = request.POST.get('farm_id')
        farm = get_object_or_404(Farm, pk=farm_id, user=request.user) if farm_id else None

        if form.is_valid() and farm:
            data = form.cleaned_data
            model = get_yield_model()
            result = model.predict(data)

            YieldPrediction.objects.create(
                farm=farm,
                crop_type=data['crop_type'],
                season=data['season'],
                year=2024,
                predicted_yield=result['predicted_yield_kg_per_acre'],
                weather_data={'temperature': data['temperature'], 'rainfall': data['rainfall']},
                soil_health_score=data['soil_ph']
            )
            messages.success(request, f"Predicted yield: {result['predicted_yield_kg_per_acre']} kg/acre")
    else:
        form = YieldPredictionForm()

    return render(request, 'agriculture_ai/yield_prediction.html', {
        'form': form, 'farms': farms, 'result': result
    })


# ─────────────────────────────────────────────────
# SOIL ANALYSIS
# ─────────────────────────────────────────────────

@login_required
def soil_analysis(request):
    farms = Farm.objects.filter(user=request.user)
    result = None

    if request.method == 'POST':
        form = SoilDataForm(request.POST)
        farm_id = request.POST.get('farm_id')
        farm = get_object_or_404(Farm, pk=farm_id, user=request.user) if farm_id else None

        if form.is_valid() and farm:
            soil = form.save(commit=False)
            soil.farm = farm
            soil.save()

            model = get_soil_model()
            result = model.analyze(
                N=soil.nitrogen, P=soil.phosphorus, K=soil.potassium,
                ph=soil.ph_level, moisture=soil.moisture,
                temperature=soil.temperature
            )
            messages.success(request, f"Soil quality: {result['soil_quality']}")
    else:
        form = SoilDataForm()

    return render(request, 'agriculture_ai/soil_analysis.html', {
        'form': form, 'farms': farms, 'result': result
    })


# ─────────────────────────────────────────────────
# IRRIGATION OPTIMIZER
# ─────────────────────────────────────────────────

@login_required
def irrigation_optimizer(request):
    farms = Farm.objects.filter(user=request.user)
    result = None

    if request.method == 'POST':
        form = IrrigationForm(request.POST)
        farm_id = request.POST.get('farm_id')
        farm = get_object_or_404(Farm, pk=farm_id, user=request.user) if farm_id else None

        if form.is_valid() and farm:
            data = form.cleaned_data
            optimizer = get_irrigation_optimizer()
            result = optimizer.optimize(**data)

            if result['should_irrigate']:
                from datetime import date
                IrrigationSchedule.objects.create(
                    farm=farm,
                    crop_type=data['crop_type'],
                    schedule_date=date.today(),
                    water_amount_liters=result['water_amount_liters'],
                    duration_minutes=result['duration_minutes'],
                    ai_recommended=True
                )
            messages.success(request, result['recommendation'])
    else:
        form = IrrigationForm()

    return render(request, 'agriculture_ai/irrigation.html', {
        'form': form, 'farms': farms, 'result': result
    })


# ─────────────────────────────────────────────────
# API ENDPOINTS (JSON)
# ─────────────────────────────────────────────────

@csrf_exempt
def api_crop_recommend(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            model = get_crop_model()
            result = model.predict(
                N=data.get('N', 50), P=data.get('P', 40), K=data.get('K', 40),
                temperature=data.get('temperature', 25), humidity=data.get('humidity', 60),
                ph=data.get('ph', 6.5), rainfall=data.get('rainfall', 100)
            )
            return JsonResponse({'success': True, 'data': result})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    return JsonResponse({'error': 'POST required'}, status=405)


@csrf_exempt
def api_yield_predict(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            model = get_yield_model()
            result = model.predict(data)
            return JsonResponse({'success': True, 'data': result})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    return JsonResponse({'error': 'POST required'}, status=405)


@csrf_exempt
def api_soil_analyze(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            model = get_soil_model()
            result = model.analyze(
                N=data.get('N', 50), P=data.get('P', 40), K=data.get('K', 40),
                ph=data.get('ph', 6.5), moisture=data.get('moisture', 40),
                temperature=data.get('temperature', 25)
            )
            return JsonResponse({'success': True, 'data': result})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    return JsonResponse({'error': 'POST required'}, status=405)


@csrf_exempt
def api_anomaly_detect(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            model = get_anomaly_model()
            readings = [
                data.get('temperature', 25), data.get('humidity', 60),
                data.get('soil_moisture', 40), data.get('ph', 6.5)
            ]
            result = model.detect(readings)
            return JsonResponse({'success': True, 'data': result})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    return JsonResponse({'error': 'POST required'}, status=405)
