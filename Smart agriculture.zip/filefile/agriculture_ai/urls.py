from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('', views.dashboard, name='dashboard'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),

    # ✅ ADD THIS LINE (IMPORTANT FIX)
    path('accounts/login/', views.login_view, name='accounts_login'),

    path('logout/', views.logout_view, name='logout'),

    # Farms
    path('farms/', views.farm_list, name='farm_list'),
    path('farms/create/', views.farm_create, name='farm_create'),
    path('farms/<int:pk>/', views.farm_detail, name='farm_detail'),

    # AI Features
    path('crop-recommendation/', views.crop_recommendation, name='crop_recommendation'),
    path('disease-detection/', views.disease_detection, name='disease_detection'),
    path('yield-prediction/', views.yield_prediction, name='yield_prediction'),
    path('soil-analysis/', views.soil_analysis, name='soil_analysis'),
    path('irrigation-optimizer/', views.irrigation_optimizer, name='irrigation_optimizer'),

    # REST API
    path('api/crop-recommend/', views.api_crop_recommend, name='api_crop_recommend'),
    path('api/yield-predict/', views.api_yield_predict, name='api_yield_predict'),
    path('api/soil-analyze/', views.api_soil_analyze, name='api_soil_analyze'),
    path('api/anomaly-detect/', views.api_anomaly_detect, name='api_anomaly_detect'),
]