"""
Management command: python manage.py train_models

Trains all ML models and saves them to the models_ml/ directory.
"""
import os
import sys
import django
from django.core.management.base import BaseCommand
from django.conf import settings

sys.path.insert(0, str(settings.BASE_DIR))


class Command(BaseCommand):
    help = 'Train and save all AI/ML models for smart agriculture'

    def add_arguments(self, parser):
        parser.add_argument('--force', action='store_true', help='Retrain even if models exist')

    def handle(self, *args, **options):
        from models_ml import (
            CropRecommendationModel, YieldPredictionModel,
            SoilAnalysisModel, AnomalyDetectionModel
        )

        models_dir = settings.ML_MODELS_DIR
        os.makedirs(models_dir, exist_ok=True)

        self.stdout.write(self.style.MIGRATE_HEADING('\n🌱 AgriAI Model Training Pipeline\n'))

        # 1. Crop Recommendation
        crop_path = settings.CROP_MODEL_PATH
        if not os.path.exists(crop_path) or options['force']:
            self.stdout.write('Training Crop Recommendation Model (Random Forest)...')
            model = CropRecommendationModel()
            acc = model.train()
            model.save(crop_path)
            self.stdout.write(self.style.SUCCESS(f'  ✅ Crop model saved. Accuracy: {acc:.4f}'))
        else:
            self.stdout.write(self.style.WARNING('  ⏭  Crop model already exists. Use --force to retrain.'))

        # 2. Yield Prediction
        yield_path = settings.YIELD_MODEL_PATH
        if not os.path.exists(yield_path) or options['force']:
            self.stdout.write('Training Yield Prediction Model (Gradient Boosting)...')
            model = YieldPredictionModel()
            rmse = model.train()
            model.save(yield_path)
            self.stdout.write(self.style.SUCCESS(f'  ✅ Yield model saved. RMSE: {rmse:.2f}'))
        else:
            self.stdout.write(self.style.WARNING('  ⏭  Yield model already exists. Use --force to retrain.'))

        # 3. Soil Analysis
        soil_path = settings.SOIL_MODEL_PATH
        if not os.path.exists(soil_path) or options['force']:
            self.stdout.write('Training Soil Analysis Model (SVM + KMeans)...')
            model = SoilAnalysisModel()
            model.train()
            model.save(soil_path)
            self.stdout.write(self.style.SUCCESS('  ✅ Soil model saved.'))
        else:
            self.stdout.write(self.style.WARNING('  ⏭  Soil model already exists. Use --force to retrain.'))

        # 4. Anomaly Detection
        anomaly_path = models_dir / 'anomaly_model.pkl'
        if not os.path.exists(anomaly_path) or options['force']:
            self.stdout.write('Training Anomaly Detection Model (Isolation Forest)...')
            model = AnomalyDetectionModel()
            model.train()
            model.save(anomaly_path)
            self.stdout.write(self.style.SUCCESS('  ✅ Anomaly model saved.'))
        else:
            self.stdout.write(self.style.WARNING('  ⏭  Anomaly model already exists.'))

        self.stdout.write(self.style.SUCCESS('\n🎉 All models trained and saved successfully!\n'))
