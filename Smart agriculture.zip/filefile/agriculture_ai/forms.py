from django import forms
from .models import Farm, SoilData, DiseaseDetection, YieldPrediction, IrrigationSchedule


class FarmForm(forms.ModelForm):
    class Meta:
        model = Farm
        fields = ['name', 'location', 'area_acres', 'soil_type', 'latitude', 'longitude']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Farm name'}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Location'}),
            'area_acres': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}),
            'soil_type': forms.Select(attrs={'class': 'form-select'}),
            'latitude': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.0001'}),
            'longitude': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.0001'}),
        }


class SoilDataForm(forms.ModelForm):
    class Meta:
        model = SoilData
        fields = ['nitrogen', 'phosphorus', 'potassium', 'ph_level', 'moisture', 'temperature', 'humidity', 'rainfall']
        widgets = {
            'nitrogen': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': 'kg/ha'}),
            'phosphorus': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': 'kg/ha'}),
            'potassium': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': 'kg/ha'}),
            'ph_level': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0', 'max': '14'}),
            'moisture': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': '%'}),
            'temperature': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': '°C'}),
            'humidity': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': '%'}),
            'rainfall': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'placeholder': 'mm'}),
        }


class DiseaseDetectionForm(forms.ModelForm):
    class Meta:
        model = DiseaseDetection
        fields = ['crop_type', 'image']
        widgets = {
            'crop_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Rice, Wheat, Maize'}),
            'image': forms.FileInput(attrs={'class': 'form-control', 'accept': 'image/*'}),
        }


class YieldPredictionForm(forms.Form):
    crop_type = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    season = forms.ChoiceField(choices=[
        ('kharif', 'Kharif (June-Oct)'), ('rabi', 'Rabi (Nov-Apr)'), ('zaid', 'Zaid (Mar-Jun)')
    ], widget=forms.Select(attrs={'class': 'form-select'}))
    temperature = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    rainfall = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    humidity = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    soil_ph = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}))
    nitrogen = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    phosphorus = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    potassium = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    area_acres = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    irrigation_count = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    fertilizer_usage = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    pesticide_usage = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    soil_moisture = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    solar_radiation = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))


class IrrigationForm(forms.Form):
    crop_type = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    soil_moisture = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    temperature = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    humidity = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    rainfall_forecast = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    area_acres = forms.FloatField(widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1'}))
    growth_stage = forms.ChoiceField(choices=[
        ('seedling', 'Seedling'), ('vegetative', 'Vegetative'),
        ('flowering', 'Flowering'), ('maturity', 'Maturity')
    ], widget=forms.Select(attrs={'class': 'form-select'}))
