from django.contrib import admin
from .models import Farm, SoilData, CropRecommendation, DiseaseDetection, YieldPrediction, WeatherData, IrrigationSchedule, SensorData


@admin.register(Farm)
class FarmAdmin(admin.ModelAdmin):
    list_display = ['name', 'user', 'location', 'area_acres', 'soil_type', 'created_at']
    list_filter = ['soil_type', 'created_at']
    search_fields = ['name', 'location', 'user__username']


@admin.register(SoilData)
class SoilDataAdmin(admin.ModelAdmin):
    list_display = ['farm', 'nitrogen', 'phosphorus', 'potassium', 'ph_level', 'moisture', 'recorded_at']
    list_filter = ['recorded_at']


@admin.register(CropRecommendation)
class CropRecommendationAdmin(admin.ModelAdmin):
    list_display = ['farm', 'recommended_crop', 'confidence_score', 'created_at']
    list_filter = ['recommended_crop', 'created_at']


@admin.register(DiseaseDetection)
class DiseaseDetectionAdmin(admin.ModelAdmin):
    list_display = ['farm', 'crop_type', 'disease_name', 'severity', 'confidence_score', 'detected_at']
    list_filter = ['severity', 'detected_at']


@admin.register(YieldPrediction)
class YieldPredictionAdmin(admin.ModelAdmin):
    list_display = ['farm', 'crop_type', 'season', 'year', 'predicted_yield', 'actual_yield']
    list_filter = ['season', 'year']


@admin.register(IrrigationSchedule)
class IrrigationAdmin(admin.ModelAdmin):
    list_display = ['farm', 'crop_type', 'schedule_date', 'water_amount_liters', 'status']
    list_filter = ['status', 'schedule_date']


@admin.register(SensorData)
class SensorDataAdmin(admin.ModelAdmin):
    list_display = ['farm', 'sensor_id', 'sensor_type', 'value', 'unit', 'is_anomaly', 'timestamp']
    list_filter = ['sensor_type', 'is_anomaly']
